extends Node2D
## TREASURE HUNTERS - port dari versi HTML5 ke Godot 4.
## Semua logika ada di skrip ini; semua aset dimuat lewat kode (tidak perlu setup scene manual).

const VW := 800.0
const VH := 448.0
const T := 32          # ukuran tile
const GR := 1500.0     # gravitasi
const RW := 14         # jumlah baris tile

# Jumlah frame tiap aset (folder res://assets/<nama>/<index>.png)
const COUNTS := {
	"idle": 5, "run": 6, "jump": 3, "fall": 1, "throw": 3, "hit": 4, "sword": 4,
	"cIdle": 1, "cFire": 6, "cBall": 1, "cHit": 4, "cDead": 4, "cExp": 7,
	"g0": 4, "g1": 4, "g2": 4, "flag": 9, "crab": 6, "crabD": 4,
	"ter2": 1, "spike": 1, "terrain": 1, "bg": 1, "clouds": 1,
}
const SFX_NAMES := ["jump", "throw", "cannon_die", "cannon_hit", "crab_die", "hurt", "shoot", "gem", "clear"]

# Level: g=tanah [dari,sampai], p=platform [baris,dari,sampai], gm=gem [baris,dari,sampai],
# c=meriam [baris,kolom], sk=duri [baris,dari,sampai], cb=kepiting [baris,kolom], s=spawn [baris,kolom], f=kolom bendera
const LV := [
	{
		"w": 64,
		"g": [[0, 19], [23, 40], [44, 63]],
		"p": [[9, 12, 15], [9, 27, 30], [8, 34, 37], [9, 45, 48]],
		"gm": [[11, 5, 8], [8, 12, 15], [10, 20, 22], [11, 25, 26], [8, 27, 30], [7, 34, 37], [11, 38, 39], [10, 41, 43], [8, 45, 48], [11, 52, 56], [11, 59, 60]],
		"c": [[11, 32], [11, 54]],
		"s": [11, 2],
		"f": 62,
	},
	{
		"w": 90,
		"ship": true,
		"g": [[0, 14], [18, 34], [38, 60], [64, 89]],
		"p": [[9, 8, 11], [9, 21, 24], [8, 28, 31], [9, 42, 45], [7, 47, 50], [9, 54, 57], [9, 68, 72], [7, 76, 80]],
		"sk": [[11, 12, 13], [11, 31, 32], [11, 40, 41], [11, 58, 59], [11, 66, 67], [11, 84, 85]],
		"gm": [[11, 3, 6], [8, 8, 11], [10, 12, 13], [10, 15, 17], [8, 21, 24], [7, 28, 31], [10, 35, 37], [10, 40, 41], [8, 42, 45], [6, 47, 50], [8, 54, 57], [10, 61, 63], [10, 66, 67], [8, 68, 72], [6, 76, 80], [11, 86, 88]],
		"cb": [[11, 22], [11, 30], [11, 44], [11, 56], [11, 70], [11, 82]],
		"c": [[11, 26], [11, 49], [11, 78]],
		"s": [11, 2],
		"f": 88,
	},
]

# --- state ---
var IM := {}
var SFX := {}
var players: Array = []
var pi := 0

var st := "menu"      # menu | play | clear | win | over
var lvl := 0
var score := 0
var lives := 3
var tt := 0.0

var W := 64
var ship := false
var grid: Array = []
var P := {}
var gems: Array = []
var cans: Array = []
var crabs: Array = []
var spk: Array = []
var swords: Array = []
var balls: Array = []
var fx: Array = []
var cam := 0.0
var flagX := 0.0
var spx := 0.0
var spy := 0.0
var gotG := 0

var keys := {"left": false, "right": false, "up": false, "throw": false}
var touches := {}
var touch_ui := false
var camr := 0.0

# tombol sentuh: [aksi, posisi]
const TBTN := [
	["left", Vector2(60, 388)], ["right", Vector2(160, 388)],
	["throw", Vector2(640, 388)], ["up", Vector2(740, 388)],
]
const TBTN_R := 40.0


func _ready() -> void:
	for k in COUNTS:
		var arr: Array = []
		for i in COUNTS[k]:
			arr.append(load("res://assets/%s/%d.png" % [k, i]))
		IM[k] = arr
	for n in SFX_NAMES:
		SFX[n] = load("res://sfx/%s.wav" % n)
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	touch_ui = DisplayServer.is_touchscreen_available()
	_load_level(0)


func sfx(n: String) -> void:
	var p: AudioStreamPlayer = players[pi]
	pi = (pi + 1) % players.size()
	p.stream = SFX[n]
	p.play()


# ---------------------------------------------------------------- level
func _load_level(i: int) -> void:
	var s: Dictionary = LV[i]
	W = s["w"]
	ship = s.has("ship")
	grid = []
	for r in RW:
		var row: Array = []
		row.resize(W)
		row.fill(0)
		grid.append(row)
	for seg in s["g"]:
		for c in range(seg[0], seg[1] + 1):
			grid[12][c] = 1
			grid[13][c] = 1
	for pl in s["p"]:
		for c in range(pl[1], pl[2] + 1):
			grid[pl[0]][c] = 1

	gems = []
	for gm in s["gm"]:
		for c in range(gm[1], gm[2] + 1):
			gems.append({"x": float(c * T + 16), "y": float(gm[0] * T + 16), "k": (gm[0] + c) % 3, "ph": c})

	cans = []
	for cn in s["c"]:
		cans.append({"x": float(cn[1] * T + 16), "yb": float((cn[0] + 1) * T), "hp": 2, "s": "idle",
			"t": 0.0, "cd": 1.0 + randf() * 1.5, "f": -1})

	spx = float(s["s"][1] * T + 6)
	spy = float((s["s"][0] + 1) * T - 28)
	flagX = float(s["f"] * T)

	crabs = []
	for cb in s.get("cb", []):
		crabs.append({"x": float(cb[1] * T + 16), "y": float((cb[0] + 1) * T), "d": -1, "t": 0.0, "dead": false})

	spk = []
	for sk in s.get("sk", []):
		for c in range(sk[1], sk[2] + 1):
			spk.append({"x": float(c * T), "y": float(sk[0] * T)})

	swords = []
	balls = []
	fx = []
	gotG = 0
	P = {"x": spx, "y": spy, "w": 20.0, "h": 28.0, "vx": 0.0, "vy": 0.0, "d": 1,
		"gnd": false, "inv": 0.0, "hit": 0.0, "thr": 0.0, "cd": 0.0, "t": 0.0}
	cam = 0.0


func cell(v: float) -> int:
	return floori(v / T)


func sol(c: int, r: int) -> bool:
	if c < 0 or c >= W:
		return true
	if r < 0 or r >= RW:
		return false
	return grid[r][c] != 0


func mvx(o: Dictionary, d: float) -> bool:
	o["x"] += d
	var a := cell(o["x"])
	var b := cell(o["x"] + o["w"] - 0.01)
	var r0 := cell(o["y"])
	var r1 := cell(o["y"] + o["h"] - 0.01)
	for r in range(r0, r1 + 1):
		for c in range(a, b + 1):
			if sol(c, r):
				o["x"] = float(c * T) - o["w"] if d > 0.0 else float((c + 1) * T)
				return true
	return false


func mvy(o: Dictionary, d: float) -> bool:
	o["y"] += d
	var a := cell(o["x"])
	var b := cell(o["x"] + o["w"] - 0.01)
	var r0 := cell(o["y"])
	var r1 := cell(o["y"] + o["h"] - 0.01)
	for r in range(r0, r1 + 1):
		for c in range(a, b + 1):
			if sol(c, r):
				o["y"] = float(r * T) - o["h"] if d > 0.0 else float((r + 1) * T)
				return true
	return false


func hurt(fall: bool = false) -> void:
	if P["inv"] > 0.0 and not fall:
		return
	lives -= 1
	sfx("hurt")
	P["inv"] = 1.6
	P["hit"] = 0.4
	if lives <= 0:
		st = "over"
		return
	if fall:
		P["x"] = spx
		P["y"] = spy
		P["vx"] = 0.0
		P["vy"] = 0.0


func start() -> void:
	score = 0
	lives = 3
	lvl = 0
	_load_level(0)
	st = "play"


func act() -> void:
	if st == "menu" or st == "over" or st == "win":
		start()
	elif st == "clear":
		lvl += 1
		_load_level(lvl)
		st = "play"


# ---------------------------------------------------------------- input
func _input(event) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			touches[event.index] = event.position
		else:
			touches.erase(event.index)
	elif event is InputEventScreenDrag:
		touches[event.index] = event.position
	elif event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT and st != "play":
			act()
	elif event is InputEventKey:
		if event.pressed and not event.echo and (event.keycode == KEY_ENTER or event.keycode == KEY_KP_ENTER):
			act()


func _read_input() -> void:
	keys["left"] = Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A)
	keys["right"] = Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D)
	keys["up"] = Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_SPACE)
	keys["throw"] = Input.is_key_pressed(KEY_J) or Input.is_key_pressed(KEY_X) or Input.is_key_pressed(KEY_Z)
	for tp in touches.values():
		for b in TBTN:
			if (tp as Vector2).distance_to(b[1]) < TBTN_R + 10.0:
				keys[b[0]] = true


func _process(delta: float) -> void:
	var dt := minf(delta, 1.0 / 30.0)
	_read_input()
	_update(dt)
	queue_redraw()


# ---------------------------------------------------------------- update
func _update(dt: float) -> void:
	tt += dt
	if st != "play":
		return

	var l: bool = keys["left"]
	var r: bool = keys["right"]
	if P["hit"] > 0.0:
		P["vx"] = 0.0
	else:
		P["vx"] = ((1 if r else 0) - (1 if l else 0)) * 200.0
	if r and not l:
		P["d"] = 1
	if l and not r:
		P["d"] = -1
	if keys["up"] and P["gnd"]:
		P["vy"] = -560.0
		sfx("jump")
	P["vy"] = minf(P["vy"] + GR * dt, 850.0)
	mvx(P, P["vx"] * dt)
	if P["x"] < 0.0:
		P["x"] = 0.0
	var h := mvy(P, P["vy"] * dt)
	if h:
		P["gnd"] = P["vy"] > 0.0
		P["vy"] = 0.0
	else:
		P["gnd"] = false

	P["t"] += dt
	P["inv"] = maxf(0.0, P["inv"] - dt)
	P["hit"] = maxf(0.0, P["hit"] - dt)
	P["thr"] = maxf(0.0, P["thr"] - dt)
	P["cd"] = maxf(0.0, P["cd"] - dt)

	if keys["throw"] and P["cd"] <= 0.0:
		P["cd"] = 0.45
		P["thr"] = 0.25
		swords.append({"x": P["x"] + 10.0 + P["d"] * 14.0, "y": P["y"] + 10.0, "d": P["d"], "dist": 0.0})
		sfx("throw")

	if P["y"] > VH + 60.0:
		hurt(true)

	# pedang
	for i in range(swords.size() - 1, -1, -1):
		var s: Dictionary = swords[i]
		var m := 380.0 * dt
		s["x"] += s["d"] * m
		s["dist"] += m
		var dead: bool = s["dist"] > 440.0 or sol(cell(s["x"]), cell(s["y"]))
		for c in cans:
			if c["s"] != "dead" and absf(s["x"] - c["x"]) < 20.0 and s["y"] > c["yb"] - 28.0 and s["y"] < c["yb"]:
				dead = true
				c["hp"] -= 1
				if c["hp"] <= 0:
					c["s"] = "dead"
					c["t"] = 0.0
					score += 150
					sfx("cannon_die")
				else:
					c["s"] = "hit"
					c["t"] = 0.0
					sfx("cannon_hit")
				break
		for b in crabs:
			if not b["dead"] and absf(s["x"] - b["x"]) < 24.0 and absf(s["y"] - (b["y"] - 10.0)) < 16.0:
				dead = true
				b["dead"] = true
				b["t"] = 0.0
				score += 100
				sfx("crab_die")
		if dead:
			swords.remove_at(i)

	# kepiting
	for i in range(crabs.size() - 1, -1, -1):
		var b: Dictionary = crabs[i]
		b["t"] += dt
		if b["dead"]:
			if b["t"] > 0.5:
				crabs.remove_at(i)
			continue
		var ah: float = b["x"] + b["d"] * 20.0
		if sol(cell(ah), cell(b["y"] - 4.0)) or not sol(cell(ah), cell(b["y"] + 4.0)):
			b["d"] *= -1
		else:
			b["x"] += b["d"] * 55.0 * dt
		if absf(b["x"] - (P["x"] + 10.0)) < 24.0 and P["y"] + P["h"] > b["y"] - 22.0 and P["y"] < b["y"]:
			hurt()

	# duri
	for k in spk:
		if P["x"] + P["w"] > k["x"] + 5.0 and P["x"] < k["x"] + T - 5.0 and P["y"] + P["h"] > k["y"] + 18.0 and P["y"] < k["y"] + T:
			hurt()

	# meriam
	for i in range(cans.size() - 1, -1, -1):
		var c: Dictionary = cans[i]
		c["t"] += dt
		if c["s"] == "dead":
			if c["t"] > 0.5:
				cans.remove_at(i)
			continue
		c["f"] = 1 if P["x"] > c["x"] else -1
		if c["s"] == "fire" and c["t"] > 0.36:
			c["s"] = "idle"
		if c["s"] == "hit" and c["t"] > 0.32:
			c["s"] = "idle"
		if c["s"] == "idle" and absf(P["x"] - c["x"]) < 440.0 and absf(P["y"] - c["yb"]) < 170.0:
			c["cd"] -= dt
			if c["cd"] <= 0.0:
				c["cd"] = 2.2
				c["s"] = "fire"
				c["t"] = 0.0
				balls.append({"x": c["x"] + c["f"] * 20.0, "y": c["yb"] - 16.0, "d": c["f"]})
				sfx("shoot")

	# peluru meriam
	for i in range(balls.size() - 1, -1, -1):
		var b: Dictionary = balls[i]
		b["x"] += b["d"] * 190.0 * dt
		var dead: bool = sol(cell(b["x"]), cell(b["y"])) or b["x"] < -20.0 or b["x"] > W * T + 20.0
		if not dead and absf(b["x"] - (P["x"] + 10.0)) < 14.0 and absf(b["y"] - (P["y"] + 14.0)) < 18.0:
			dead = true
			hurt()
		if dead:
			fx.append({"x": b["x"], "y": b["y"], "t": 0.0})
			balls.remove_at(i)

	# efek ledakan
	for i in range(fx.size() - 1, -1, -1):
		fx[i]["t"] += dt
		if fx[i]["t"] > 0.42:
			fx.remove_at(i)

	# gem
	for i in range(gems.size() - 1, -1, -1):
		var g: Dictionary = gems[i]
		if absf(g["x"] - (P["x"] + 10.0)) < 20.0 and absf(g["y"] - (P["y"] + 14.0)) < 24.0:
			score += [50, 75, 100][g["k"]]
			gotG += 1
			gems.remove_at(i)
			sfx("gem")

	# bendera / selesai level
	if P["x"] + P["w"] > flagX + 8.0 and P["y"] > 0.0:
		score += 200
		st = "win" if lvl >= LV.size() - 1 else "clear"
		sfx("clear")

	cam = maxf(0.0, minf(W * T - VW, P["x"] + 10.0 - VW / 2.0))


# ---------------------------------------------------------------- draw
func ring(name: String, t: float, fps: float) -> Texture2D:
	var a: Array = IM[name]
	return a[floori(t * fps) % a.size()]


func txt(s: String, x: float, y: float, sz: int, col: Color = Color.WHITE, center: bool = true) -> void:
	var f := ThemeDB.fallback_font
	var px := x - VW / 2.0 if center else x
	var w := VW if center else -1.0
	var ha: int = HORIZONTAL_ALIGNMENT_CENTER if center else HORIZONTAL_ALIGNMENT_LEFT
	draw_string_outline(f, Vector2(px, y), s, ha, w, sz, 4, Color(0, 0, 0, 0.73))
	draw_string(f, Vector2(px, y), s, ha, w, sz, col)


func heart(cx: float, cy: float, col: Color) -> void:
	draw_circle(Vector2(cx - 5.5, cy - 3.0), 6.0, col)
	draw_circle(Vector2(cx + 5.5, cy - 3.0), 6.0, col)
	draw_colored_polygon(PackedVector2Array([Vector2(cx - 11.0, cy - 1.0), Vector2(cx + 11.0, cy - 1.0), Vector2(cx, cy + 12.0)]), col)


func world_xf(pos: Vector2 = Vector2.ZERO, sx: float = 1.0) -> void:
	draw_set_transform(Vector2(pos.x - camr, pos.y), 0.0, Vector2(sx, 1.0))


func tile(src: Vector2, dst: Vector2, tex: Texture2D) -> void:
	draw_texture_rect_region(tex, Rect2(dst, Vector2(T, T)), Rect2(src, Vector2(T, T)))


func _g(c: int, r: int) -> int:
	return grid[r][c]


func _draw() -> void:
	camr = roundf(cam)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# latar belakang
	if not ship:
		var bw := 1344.0
		var x0 := -fmod(cam * 0.2, bw)
		var bg: Texture2D = IM["bg"][0]
		draw_texture_rect(bg, Rect2(x0, 0, bw, VH), false)
		draw_texture_rect(bg, Rect2(x0 + bw, 0, bw, VH), false)
		var cw := 896.0
		var x1 := -fmod(cam * 0.4 + tt * 8.0, cw)
		var cl: Texture2D = IM["clouds"][0]
		draw_texture_rect(cl, Rect2(x1, 20, cw, 202), false)
		draw_texture_rect(cl, Rect2(x1 + cw, 20, cw, 202), false)
	else:
		draw_rect(Rect2(0, 0, VW, VH), Color("1a1214"))

	world_xf()
	var ca := floori(cam / T)
	var cb := ca + ceili(VW / T) + 1
	var ter: Texture2D = IM["ter2"][0] if ship else IM["terrain"][0]
	var o := 32 if ship else 0
	if ship:
		for r in RW:
			for c in range(ca, cb + 1):
				tile(Vector2(64, 256), Vector2(c * T, r * T), ter)
		draw_rect(Rect2(ca * T, 0, (cb - ca + 1) * T, VH), Color(0, 0, 0, 0.67))

	for r in RW:
		for c in range(ca, mini(cb, W - 1) + 1):
			if c < 0 or _g(c, r) == 0:
				continue
			var u := 0
			if r > 0 and _g(c, r - 1) == 0:
				u = 0
			elif r < RW - 1 and _g(c, r + 1) == 0:
				u = 2
			else:
				u = 1
			var lf := 0
			if c > 0 and _g(c - 1, r) == 0:
				lf = 0
			elif c < W - 1 and _g(c + 1, r) == 0:
				lf = 2
			else:
				lf = 1
			tile(Vector2(o + lf * T, o + u * T), Vector2(c * T, r * T), ter)

	for k in spk:
		draw_texture(IM["spike"][0], Vector2(k["x"], k["y"]))

	for b in crabs:
		var im: Texture2D
		if b["dead"]:
			im = IM["crabD"][mini(3, floori(b["t"] / 0.12))]
		else:
			im = ring("crab", tt, 10.0)
		draw_texture(im, Vector2(roundf(b["x"] - 36.0), roundf(b["y"] - 27.0)))

	draw_texture(ring("flag", tt, 10.0), Vector2(flagX, 12 * T - 93))

	for g in gems:
		var gi: Texture2D = ring("g%d" % g["k"], tt + g["ph"] * 0.1, 8.0)
		draw_texture(gi, Vector2(g["x"] - 12.0, g["y"] - 12.0 + sin(tt * 3.0 + g["ph"]) * 3.0))

	for c in cans:
		var im: Texture2D
		if c["s"] == "dead":
			im = IM["cDead"][mini(3, floori(c["t"] / 0.12))]
		elif c["s"] == "fire":
			im = IM["cFire"][mini(5, floori(c["t"] / 0.06))]
		elif c["s"] == "hit":
			im = IM["cHit"][mini(3, floori(c["t"] / 0.08))]
		else:
			im = IM["cIdle"][0]
		world_xf(Vector2(c["x"], c["yb"] - 26.0), -1.0 if c["f"] > 0 else 1.0)
		draw_texture(im, Vector2(-20, 0))
	world_xf()

	for b in balls:
		draw_texture(IM["cBall"][0], Vector2(b["x"] - 8.0, b["y"] - 8.0))
	for s in swords:
		draw_texture(ring("sword", tt, 20.0), Vector2(s["x"] - 10.0, s["y"] - 10.0))
	for f in fx:
		draw_texture(IM["cExp"][mini(6, floori(f["t"] / 0.06))], Vector2(f["x"] - 27.0, f["y"] - 36.0))

	# pemain (berkedip saat kebal)
	var blink: bool = P["inv"] > 0.0 and P["hit"] <= 0.0 and int(floor(P["inv"] * 12.0)) % 2 == 1
	if st != "over" and not blink:
		var pim: Texture2D
		if P["hit"] > 0.0:
			pim = IM["hit"][clampi(floori((0.4 - P["hit"]) / 0.1), 0, 3)]
		elif P["thr"] > 0.0:
			pim = IM["throw"][clampi(floori((0.25 - P["thr"]) / 0.084), 0, 2)]
		elif not P["gnd"]:
			if P["vy"] < -250.0:
				pim = IM["jump"][0]
			elif P["vy"] < 0.0:
				pim = IM["jump"][1]
			elif P["vy"] < 150.0:
				pim = IM["jump"][2]
			else:
				pim = IM["fall"][0]
		elif P["vx"] != 0.0:
			pim = ring("run", P["t"], 12.0)
		else:
			pim = ring("idle", P["t"], 8.0)
		world_xf(Vector2(roundf(P["x"] + 10.0), roundf(P["y"] + P["h"] - 32.0)), float(P["d"]))
		draw_texture(pim, Vector2(-30, 0))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# HUD
	txt("Skor %d" % score, 16, 32, 22, Color("ffe27a"), false)
	txt("Level %d/%d" % [lvl + 1, LV.size()], VW / 2.0, 32, 20)
	for i in 3:
		heart(VW - 24.0 - i * 30.0, 22.0, Color("ff4d5e") if i < lives else Color(0.2, 0.2, 0.2, 0.53))

	# tombol sentuh
	if touch_ui and st == "play":
		for b in TBTN:
			var pos: Vector2 = b[1]
			draw_circle(pos, TBTN_R, Color(1, 1, 1, 0.19))
			draw_arc(pos, TBTN_R, 0.0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
			match b[0]:
				"left":
					draw_colored_polygon(PackedVector2Array([pos + Vector2(-14, 0), pos + Vector2(8, -14), pos + Vector2(8, 14)]), Color(1, 1, 1, 0.8))
				"right":
					draw_colored_polygon(PackedVector2Array([pos + Vector2(14, 0), pos + Vector2(-8, -14), pos + Vector2(-8, 14)]), Color(1, 1, 1, 0.8))
				"up":
					draw_colored_polygon(PackedVector2Array([pos + Vector2(0, -14), pos + Vector2(-14, 8), pos + Vector2(14, 8)]), Color(1, 1, 1, 0.8))
				"throw":
					draw_texture_rect(IM["sword"][0], Rect2(pos - Vector2(20, 20), Vector2(40, 40)), false)

	# layar menu / status
	if st == "menu":
		draw_rect(Rect2(0, 0, VW, VH), Color(0, 0, 0, 0.67))
		txt("TREASURE HUNTERS", VW / 2.0, 150, 52, Color("ffe27a"))
		txt("Level 1 pulau, Level 2 dalam kapal: awas duri, kepiting, dan meriam!", VW / 2.0, 205, 20)
		txt("Nyawa 3 · kena musuh/jebakan/tembakan = -1 nyawa · jatuh ke jurang = -1 nyawa", VW / 2.0, 235, 17)
		txt("Tekan ENTER / ketuk layar untuk mulai", VW / 2.0, 310, 26)
		txt("A D / panah kiri-kanan jalan · Spasi / W / panah atas lompat · J / X lempar pedang", VW / 2.0, 360, 16)
	if st == "clear" or st == "win" or st == "over":
		draw_rect(Rect2(0, 0, VW, VH), Color(0, 0, 0, 0.73))
		if st == "clear":
			txt("Level %d selesai!" % (lvl + 1), VW / 2.0, 170, 46, Color("7dff9a"))
			txt("Bonus +200 · Gem: %d · Skor: %d" % [gotG, score], VW / 2.0, 225, 24)
			txt("Tekan ENTER / ketuk untuk lanjut", VW / 2.0, 290, 24)
		if st == "win":
			txt("KAMU MENANG!", VW / 2.0, 170, 52, Color("ffe27a"))
			txt("Total skor: %d" % score, VW / 2.0, 230, 32)
			txt("Tekan ENTER / ketuk untuk main lagi", VW / 2.0, 295, 24)
		if st == "over":
			txt("GAME OVER", VW / 2.0, 170, 56, Color("ff6b6b"))
			txt("Total skor: %d" % score, VW / 2.0, 230, 32)
			txt("Tekan ENTER / ketuk untuk coba lagi", VW / 2.0, 295, 24)
